---
name: 特性请求
about: 创建一个特性请求
title: ''
labels: 'enhancement'
assignees: ''

---

# 警告：请认真填写以下栏目，如果不符合要求，将直接被关闭。编辑完请删除此行。

**特性描述**
